Please read and understand the Field Suite's Instructional Guide.  This will help you in understanding the functionality provided as well as how to make customizations to the module.  You can find the guide on the Velir Blog (http://blog.velir.com).

This file will overwrite the Content Manager's default.aspx file during the installation process.  